package com.example.swe_6733_group_3_adventura

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
